import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:ststore/screens/products/product_detail_screen.dart';

class CatalogScreen extends StatefulWidget {
  @override
  _CatalogScreenState createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  bool isGridView = true;
  String searchQuery = '';

  final TextEditingController _searchController = TextEditingController();
  final CollectionReference products = FirebaseFirestore.instance.collection(
    'products',
  );

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(120),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF2E3A47), Color(0xFF3D4A5C)],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                // AppBar
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Ürün Kataloğu',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          isGridView ? Icons.view_list : Icons.grid_view,
                          color: Colors.white,
                        ),
                        onPressed:
                            () => setState(() => isGridView = !isGridView),
                      ),
                    ],
                  ),
                ),

                // Arama kutusu
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Ürün ara...',
                      prefixIcon: Icon(Icons.search, color: Colors.grey[600]),
                      suffixIcon:
                          searchQuery.isNotEmpty
                              ? IconButton(
                                icon: Icon(
                                  Icons.clear,
                                  color: Colors.grey[600],
                                ),
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() => searchQuery = '');
                                },
                              )
                              : null,
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 15,
                      ),
                    ),
                    onChanged: (value) {
                      setState(() => searchQuery = value.toLowerCase());
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: products.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64, color: Colors.red),
                  SizedBox(height: 16),
                  Text(
                    'Bir hata oluştu',
                    style: TextStyle(fontSize: 18, color: Colors.red),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Lütfen tekrar deneyin',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Color(0xFF2E3A47),
                    ),
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Ürünler yükleniyor...',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            );
          }

          List<DocumentSnapshot> filteredDocs = snapshot.data!.docs;

          // Arama filtresi uygula
          if (searchQuery.isNotEmpty) {
            filteredDocs =
                filteredDocs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final name =
                      data['productName']?.toString().toLowerCase() ?? '';
                  final category =
                      data['category']?.toString().toLowerCase() ?? '';
                  final description =
                      data['description']?.toString().toLowerCase() ?? '';

                  return name.contains(searchQuery) ||
                      category.contains(searchQuery) ||
                      description.contains(searchQuery);
                }).toList();
          }

          if (filteredDocs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.search_off, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    searchQuery.isNotEmpty
                        ? 'Aradığınız ürün bulunamadı'
                        : 'Henüz ürün eklenmemiş',
                    style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                  ),
                  if (searchQuery.isNotEmpty) ...[
                    SizedBox(height: 8),
                    Text(
                      'Farklı anahtar kelimeler deneyin',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ],
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: () async {
              setState(() {});
            },
            color: Color(0xFF2E3A47),
            child:
                isGridView
                    ? _buildGridView(filteredDocs)
                    : _buildListView(filteredDocs),
          );
        },
      ),
    );
  }

  Widget _buildGridView(List<DocumentSnapshot> docs) {
    return GridView.builder(
      padding: EdgeInsets.all(16),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 0.75,
      ),
      itemCount: docs.length,
      itemBuilder: (context, index) {
        final data = docs[index].data() as Map<String, dynamic>;
        return _buildProductCard(data, docs[index].id);
      },
    );
  }

  Widget _buildListView(List<DocumentSnapshot> docs) {
    return ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: docs.length,
      itemBuilder: (context, index) {
        final data = docs[index].data() as Map<String, dynamic>;
        return _buildProductListTile(data, docs[index].id);
      },
    );
  }

  Widget _buildProductCard(Map<String, dynamic> product, String productId) {
    return Hero(
      tag: 'product_$productId',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _navigateToProductDetail(product, productId),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 12,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Ürün Resmi
                Expanded(
                  flex: 3,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(16),
                      ),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Colors.grey[100]!, Colors.grey[200]!],
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(16),
                      ),
                      child:
                          product['imageUrl'] != null &&
                                  product['imageUrl'].isNotEmpty
                              ? CachedNetworkImage(
                                imageUrl: product['imageUrl'],
                                fit: BoxFit.cover,
                                width: double.infinity,
                                placeholder:
                                    (context, url) => Center(
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Color(0xFF2E3A47),
                                            ),
                                      ),
                                    ),
                                errorWidget:
                                    (context, url, error) => Center(
                                      child: Icon(
                                        Icons.inventory,
                                        size: 48,
                                        color: Colors.grey[400],
                                      ),
                                    ),
                              )
                              : Center(
                                child: Icon(
                                  Icons.inventory,
                                  size: 48,
                                  color: Colors.grey[400],
                                ),
                              ),
                    ),
                  ),
                ),

                // Ürün Bilgileri
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product['productName'] ?? 'Ürün Adı',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: Color(0xFF2E3A47),
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            SizedBox(height: 4),
                            Container(
                              padding: EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: Color(0xFF2E3A47).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                product['category'] ?? 'Kategori',
                                style: TextStyle(
                                  color: Color(0xFF2E3A47),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '₺${product['price']?.toString() ?? '0.00'}',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Color(0xFF2E3A47),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: Color(0xFF2E3A47),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.arrow_forward,
                                size: 16,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProductListTile(Map<String, dynamic> product, String productId) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        leading: Hero(
          tag: 'product_image_$productId',
          child: Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.grey[100]!, Colors.grey[200]!],
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child:
                  product['imageUrl'] != null && product['imageUrl'].isNotEmpty
                      ? CachedNetworkImage(
                        imageUrl: product['imageUrl'],
                        fit: BoxFit.cover,
                        placeholder:
                            (context, url) => Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  Color(0xFF2E3A47),
                                ),
                                strokeWidth: 2,
                              ),
                            ),
                        errorWidget:
                            (context, url, error) => Icon(
                              Icons.inventory,
                              color: Colors.grey[400],
                              size: 32,
                            ),
                      )
                      : Icon(
                        Icons.inventory,
                        color: Colors.grey[400],
                        size: 32,
                      ),
            ),
          ),
        ),
        title: Text(
          product['productName'] ?? 'Ürün Adı',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color(0xFF2E3A47),
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 4),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: Color(0xFF2E3A47).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                product['category'] ?? 'Kategori',
                style: TextStyle(
                  color: Color(0xFF2E3A47),
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            SizedBox(height: 8),
            Text(
              '₺${product['price']?.toString() ?? '0.00'}',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xFF2E3A47),
                fontSize: 16,
              ),
            ),
          ],
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: 16,
          color: Color(0xFF2E3A47),
        ),
        onTap: () => _navigateToProductDetail(product, productId),
      ),
    );
  }

  void _navigateToProductDetail(Map<String, dynamic> product, String productId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductDetailScreen(),
        settings: RouteSettings(
          arguments: {
            'productId': productId,
          },
        ),
      ),
    );
  }
}
