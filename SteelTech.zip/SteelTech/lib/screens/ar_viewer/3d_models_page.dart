import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:ststore/screens/ar_viewer/ar_viewer_screen.dart';

class ModelsScreen extends StatefulWidget {
  @override
  State<ModelsScreen> createState() => _ModelsScreenState();
}

class _ModelsScreenState extends State<ModelsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  List<Model3D> models = [];
  List<Model3D> filteredModels = [];
  bool isLoading = true;
  String selectedCategory = 'all';
  String searchQuery = '';

  final List<String> categories = [
    'all',
    'building',
    'furniture',
    'vehicle',
    'character',
    'nature',
    'industrial',
    'decoration',
    'electronics',
    'other',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _loadModels();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadModels() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance
              .collection('3d-models')
              .where('isActive', isEqualTo: true)
              .get();

      setState(() {
        models =
            querySnapshot.docs
                .map((doc) => Model3D.fromFirestore(doc))
                .toList();

        // Sort by priority and upload date
        models.sort((a, b) {
          if (a.priority != b.priority) {
            final priorityOrder = {'featured': 3, 'high': 2, 'normal': 1};
            return (priorityOrder[b.priority] ?? 1).compareTo(
              priorityOrder[a.priority] ?? 1,
            );
          }
          return b.uploadDate.compareTo(a.uploadDate);
        });

        _filterModels();
        isLoading = false;
      });

      _animationController.forward();
    } catch (e) {
      print('Error loading models: $e');
      setState(() {
        isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Modeller yüklenirken hata oluştu'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _filterModels() {
    setState(() {
      filteredModels =
          models.where((model) {
            bool categoryMatch =
                selectedCategory == 'all' || model.category == selectedCategory;

            bool searchMatch =
                searchQuery.isEmpty ||
                model.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
                model.description.toLowerCase().contains(
                  searchQuery.toLowerCase(),
                ) ||
                model.tags.any(
                  (tag) =>
                      tag.toLowerCase().contains(searchQuery.toLowerCase()),
                );

            return categoryMatch && searchMatch;
          }).toList();
    });
  }

  void _onCategoryChanged(String category) {
    setState(() {
      selectedCategory = category;
    });
    _filterModels();
  }

  void _onSearchChanged(String query) {
    setState(() {
      searchQuery = query;
    });
    _filterModels();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          '3D Modeller',
          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
        ),
        backgroundColor: Color(0xFF667EEA),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                isLoading = true;
              });
              _loadModels();
            },
          ),
        ],
      ),
      body:
          isLoading
              ? _buildLoadingWidget()
              : FadeTransition(opacity: _fadeAnimation, child: _buildContent()),
    );
  }

  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667EEA)),
          ),
          SizedBox(height: 16),
          Text(
            'Modeller yükleniyor...',
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return Column(
      children: [
        _buildHeader(),
        _buildSearchBar(),
        Expanded(child: _buildModelGrid()),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatCard('Toplam', models.length.toString(), Icons.apps),
              _buildStatCard(
                'Aktif',
                filteredModels.length.toString(),
                Icons.visibility,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(icon, color: Colors.white, size: 24),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: TextField(
        onChanged: _onSearchChanged,
        decoration: InputDecoration(
          hintText: 'Model ara...',
          prefixIcon: Icon(Icons.search, color: Color(0xFF667EEA)),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildModelGrid() {
    if (filteredModels.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.view_in_ar, size: 64, color: Colors.grey[400]),
            SizedBox(height: 16),
            Text(
              searchQuery.isNotEmpty
                  ? 'Arama kriterlerinize uygun model bulunamadı'
                  : 'Bu kategoride henüz model bulunmuyor',
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  searchQuery = '';
                  selectedCategory = 'all';
                });
                _filterModels();
              },
              icon: Icon(Icons.refresh),
              label: Text('Filtreleri Sıfırla'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF667EEA),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadModels,
      child: GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.8,
        ),
        itemCount: filteredModels.length,
        itemBuilder: (context, index) {
          return _buildModelCard(filteredModels[index]);
        },
      ),
    );
  }

  Widget _buildModelCard(Model3D model) {
    return GestureDetector(
      onTap: () => _openModelViewer(model),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Model Preview
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF667EEA).withOpacity(0.8),
                      Color(0xFF764BA2).withOpacity(0.8),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.view_in_ar, size: 48, color: Colors.white),
                          SizedBox(height: 8),
                          Text(
                            model.getFileExtension().toUpperCase(),
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (model.priority == 'featured')
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.orange,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            'ÖNE ÇIKAN',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            // Model Info
            Expanded(
              flex: 2,
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      model.name,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2E3A47),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4),
                    if (model.description.isNotEmpty) ...[
                      SizedBox(height: 4),
                      Text(
                        model.description,
                        style: TextStyle(fontSize: 11, color: Colors.grey[600]),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _formatFileSize(model.fileSize),
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.grey[500],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: 12,
                          color: Colors.grey[400],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openModelViewer(Model3D model) {

    // URL'nin geçerli olup olmadığını kontrol et
    if (model.downloadURL.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Model indirme URL\'si bulunamadı'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ARViewerScreen(
          modelPath: model.downloadURL,
          modelName: model.name,
          modelDescription: model.description,
          isFirebaseUrl: true,
        ),
      ),
    );
  }

  String _formatFileSize(int bytes) {
    if (bytes <= 0) return '0 B';
    const suffixes = ['B', 'KB', 'MB', 'GB'];
    var i = (bytes == 0) ? 0 : (bytes.bitLength - 1) ~/ 10;
    if (i >= suffixes.length) i = suffixes.length - 1;
    return '${(bytes / (1 << (i * 10))).toStringAsFixed(1)} ${suffixes[i]}';
  }
}

// Model Class
class Model3D {
  final String id;
  final String name;
  final String category;
  final String description;
  final List<String> tags;
  final double scale;
  final String priority;
  final String fileName;
  final String originalName;
  final int fileSize;
  final String downloadURL;
  final String userId;
  final DateTime uploadDate;
  final bool isActive;
  final int downloadCount;

  Model3D({
    required this.id,
    required this.name,
    required this.category,
    required this.description,
    required this.tags,
    required this.scale,
    required this.priority,
    required this.fileName,
    required this.originalName,
    required this.fileSize,
    required this.downloadURL,
    required this.userId,
    required this.uploadDate,
    required this.isActive,
    required this.downloadCount,
  });

  factory Model3D.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    return Model3D(
      id: doc.id,
      name: data['name'] ?? 'İsimsiz Model',
      category: data['category'] ?? 'other',
      description: data['description'] ?? '',
      tags: List<String>.from(data['tags'] ?? []),
      scale: (data['scale'] ?? 1.0).toDouble(),
      priority: data['priority'] ?? 'normal',
      fileName: data['fileName'] ?? '',
      originalName: data['originalName'] ?? '',
      fileSize: data['fileSize'] ?? 0,
      downloadURL: data['downloadURL'] ?? '',
      userId: data['userId'] ?? '',
      uploadDate:
          (data['uploadDate'] as Timestamp?)?.toDate() ?? DateTime.now(),
      isActive: data['isActive'] ?? true,
      downloadCount: data['downloadCount'] ?? 0,
    );
  }

  String getFileExtension() {
    if (originalName.isEmpty) return 'file';
    return originalName.split('.').last;
  }
}

// Model Viewer Screen
class ModelViewerScreen extends StatefulWidget {
  final Model3D model;

  const ModelViewerScreen({Key? key, required this.model}) : super(key: key);

  @override
  State<ModelViewerScreen> createState() => _ModelViewerScreenState();
}

class _ModelViewerScreenState extends State<ModelViewerScreen> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _incrementDownloadCount();
    // Simulate loading time
    Future.delayed(Duration(seconds: 1), () {
      setState(() {
        isLoading = false;
      });
    });
  }

  Future<void> _incrementDownloadCount() async {
    try {
      await FirebaseFirestore.instance
          .collection('3d-models')
          .doc(widget.model.id)
          .update({
            'downloadCount': FieldValue.increment(1),
            'lastAccessed': FieldValue.serverTimestamp(),
          });
    } catch (e) {
      print('Error updating download count: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(widget.model.name, style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(icon: Icon(Icons.info_outline), onPressed: _showModelInfo),
          IconButton(icon: Icon(Icons.share), onPressed: _shareModel),
        ],
      ),
      body:
          isLoading
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                    SizedBox(height: 16),
                    Text(
                      '3D Model yükleniyor...',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
              )
              : Stack(
                children: [
                  // 3D Model Viewer will be implemented here
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.view_in_ar,
                          size: 120,
                          color: Colors.white54,
                        ),
                        SizedBox(height: 20),
                        Text(
                          widget.model.name,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Model URL: ${widget.model.downloadURL}',
                          style: TextStyle(color: Colors.white70, fontSize: 12),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 20),
                        Text(
                          '3D Model Viewer entegrasyonu\niçin model_viewer paketi\nkullanılabilir',
                          style: TextStyle(color: Colors.white70, fontSize: 14),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  // Control Panel
                  Positioned(
                    bottom: 20,
                    left: 20,
                    right: 20,
                    child: _buildControlPanel(),
                  ),
                ],
              ),
    );
  }

  Widget _buildControlPanel() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.9),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildControlButton(
            icon: Icons.rotate_left,
            label: 'Döndür',
            onTap: () {
              // Implement rotation
            },
          ),
          _buildControlButton(
            icon: Icons.zoom_in,
            label: 'Yakınlaştır',
            onTap: () {
              // Implement zoom
            },
          ),
          _buildControlButton(
            icon: Icons.zoom_out,
            label: 'Uzaklaştır',
            onTap: () {
              // Implement zoom out
            },
          ),
          _buildControlButton(
            icon: Icons.refresh,
            label: 'Sıfırla',
            onTap: () {
              // Implement reset
            },
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Color(0xFF667EEA),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.black87)),
        ],
      ),
    );
  }

  void _showModelInfo() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder:
          (context) => Container(
            height: MediaQuery.of(context).size.height * 0.7,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Model Bilgileri',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 20),
                      _buildInfoRow('Ad', widget.model.name),
                      _buildInfoRow('Kategori', widget.model.category),
                      _buildInfoRow(
                        'Dosya Boyutu',
                        _formatFileSize(widget.model.fileSize),
                      ),
                      _buildInfoRow(
                        'Format',
                        widget.model.getFileExtension().toUpperCase(),
                      ),
                      _buildInfoRow('Ölçek', widget.model.scale.toString()),
                      _buildInfoRow(
                        'İndirme Sayısı',
                        widget.model.downloadCount.toString(),
                      ),
                      if (widget.model.description.isNotEmpty) ...[
                        SizedBox(height: 16),
                        Text(
                          'Açıklama',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          widget.model.description,
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                      if (widget.model.tags.isNotEmpty) ...[
                        SizedBox(height: 16),
                        Text(
                          'Etiketler',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          children:
                              widget.model.tags
                                  .map(
                                    (tag) => Chip(
                                      label: Text(tag),
                                      backgroundColor: Color(
                                        0xFF667EEA,
                                      ).withOpacity(0.1),
                                      labelStyle: TextStyle(
                                        color: Color(0xFF667EEA),
                                      ),
                                    ),
                                  )
                                  .toList(),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label + ':',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey[600],
              ),
            ),
          ),
          Expanded(
            child: Text(value, style: TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  void _shareModel() {
    // Implement sharing functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Model paylaşım özelliği yakında eklenecek')),
    );
  }

  String _formatFileSize(int bytes) {
    if (bytes <= 0) return '0 B';
    const suffixes = ['B', 'KB', 'MB', 'GB'];
    var i = (bytes == 0) ? 0 : (bytes.bitLength - 1) ~/ 10;
    if (i >= suffixes.length) i = suffixes.length - 1;
    return '${(bytes / (1 << (i * 10))).toStringAsFixed(1)} ${suffixes[i]}';
  }
}
