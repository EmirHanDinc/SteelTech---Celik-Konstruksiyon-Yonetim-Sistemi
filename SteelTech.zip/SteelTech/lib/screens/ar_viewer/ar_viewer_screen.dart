import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:model_viewer_plus/model_viewer_plus.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';

class ARViewerScreen extends StatefulWidget {
  final String modelPath;
  final String modelName;
  final String? modelDescription;
  final bool isFirebaseUrl;

  const ARViewerScreen({
    Key? key,
    required this.modelPath,
    required this.modelName,
    this.modelDescription,
    this.isFirebaseUrl = false,
  }) : super(key: key);

  @override
  State<ARViewerScreen> createState() => _ARViewerScreenState();
}

class _ARViewerScreenState extends State<ARViewerScreen> {
  // Mevcut değişkenler
  bool autoRotate = false;
  bool cameraControls = true;
  bool arEnabled = true;
  bool showARView = false;
  bool _showInfoPanel = false;

  CameraController? _cameraController;
  List<CameraDescription>? cameras;
  bool isCameraInitialized = false;

  double _modelScale = 1.0;
  double _modelRotationY = 0.0;
  double _modelPositionX = 0.0;
  double _modelPositionY = 0.0;
  double _cameraDistance = 3.0;

  // Firebase ile ilgili yeni değişkenler
  String? _dataUrlModel; // Base64 encoded data URL
  bool _isDownloading = false;
  bool _downloadError = false;
  String _downloadProgress = '';
  double _downloadPercentage = 0.0;

  String get selectedModel {
    if (widget.isFirebaseUrl && _dataUrlModel != null) {
      // Data URL kullan (Base64 encoded)
      return _dataUrlModel!;
    } else if (!widget.isFirebaseUrl) {
      // Asset dosyası ise direkt kullan
      return widget.modelPath;
    } else {
      // Firebase URL'si ve henüz işlenmedi ise direkt URL'yi dene
      return widget.modelPath;
    }
  }

  String get modelName => widget.modelName;

  @override
  void initState() {
    super.initState();
    initializeCamera();

    // Firebase URL'si ise modeli indir ve data URL'ye çevir
    if (widget.isFirebaseUrl) {
      _downloadAndConvertModel();
    }
  }

  Future<void> _downloadAndConvertModel() async {
    if (!widget.isFirebaseUrl) return;

    setState(() {
      _isDownloading = true;
      _downloadError = false;
      _downloadProgress = 'Bağlanıyor...';
      _downloadPercentage = 0.0;
    });

    try {
      setState(() {
        _downloadProgress = 'Model indiriliyor...';
        _downloadPercentage = 0.1;
      });

      debugPrint('Firebase URL\'sinden indiriliyor: ${widget.modelPath}');

      // HTTP isteği gönder
      final request = http.Request('GET', Uri.parse(widget.modelPath));
      final response = await request.send();

      if (response.statusCode == 200) {
        final contentLength = response.contentLength ?? 0;
        final bytes = <int>[];
        int downloadedBytes = 0;

        await for (var chunk in response.stream) {
          bytes.addAll(chunk);
          downloadedBytes += chunk.length;

          if (contentLength > 0) {
            setState(() {
              _downloadPercentage = downloadedBytes / contentLength;
              _downloadProgress =
                  'İndiriliyor... ${(_downloadPercentage * 100).toInt()}%';
            });
          }
        }

        setState(() {
          _downloadProgress = 'Data URL\'ye dönüştürülüyor...';
          _downloadPercentage = 0.9;
        });

        // Bytes'ı Base64'e çevir ve data URL oluştur
        String base64String = base64Encode(bytes);
        String mimeType = _getMimeType(widget.modelPath);
        _dataUrlModel = 'data:$mimeType;base64,$base64String';

        setState(() {
          _isDownloading = false;
          _downloadProgress = 'Tamamlandı!';
          _downloadPercentage = 1.0;
        });

        debugPrint('Model data URL\'ye dönüştürüldü (${bytes.length} bytes)');
        debugPrint(
          'Data URL başlangıcı: ${_dataUrlModel!.substring(0, 100)}...',
        );
      } else {
        throw Exception('HTTP ${response.statusCode}: Server hatası');
      }
    } catch (e) {
      debugPrint('Model indirme hatası: $e');
      setState(() {
        _isDownloading = false;
        _downloadError = true;
        _downloadProgress = 'Hata: ${e.toString()}';
      });
    }
  }

  String _getMimeType(String url) {
    String extension = url.split('.').last.toLowerCase().split('?').first;
    switch (extension) {
      case 'glb':
        return 'model/gltf-binary';
      case 'gltf':
        return 'model/gltf+json';
      case 'obj':
        return 'text/plain';
      case 'fbx':
        return 'application/octet-stream';
      default:
        return 'model/gltf-binary';
    }
  }

  Future<void> initializeCamera() async {
    try {
      cameras = await availableCameras();
      if (cameras != null && cameras!.isNotEmpty) {
        CameraDescription backCamera = cameras!.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.back,
          orElse: () => cameras!.first,
        );

        _cameraController = CameraController(
          backCamera,
          ResolutionPreset.high,
          enableAudio: false,
        );

        await _cameraController!.initialize();
        setState(() {
          isCameraInitialized = true;
        });
      }
    } catch (e) {
      debugPrint('Kamera başlatma hatası: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(showARView ? 'AR: $modelName' : '3D: $modelName'),
        backgroundColor: showARView ? Colors.green : Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.info),
            onPressed: () => _showModelInfoDialog(),
            tooltip: 'Model Bilgileri',
          ),
          if (showARView)
            IconButton(
              icon: Icon(_showInfoPanel ? Icons.help : Icons.help_outline),
              onPressed: () {
                setState(() {
                  _showInfoPanel = !_showInfoPanel;
                });
              },
              tooltip: 'AR Kontrol Yardımı',
            ),
          IconButton(
            icon: Icon(showARView ? Icons.view_in_ar : Icons.view_in_ar),
            onPressed:
                _isDownloading
                    ? null
                    : () {
                      setState(() {
                        showARView = !showARView;
                        if (!showARView) {
                          _showInfoPanel = false;
                        }
                      });
                    },
            tooltip: showARView ? 'Normal Moda Geç' : 'AR Moda Geç',
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isDownloading) {
      return _buildDownloadingView();
    }

    if (_downloadError && widget.isFirebaseUrl && _dataUrlModel == null) {
      return _buildErrorView();
    }

    return showARView ? _buildARView() : _buildNormalView();
  }

  Widget _buildDownloadingView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 100,
                  height: 100,
                  child: CircularProgressIndicator(
                    strokeWidth: 8,
                    value: _downloadPercentage > 0 ? _downloadPercentage : null,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
                    backgroundColor: Colors.blue.withOpacity(0.2),
                  ),
                ),
                Icon(Icons.cloud_download, size: 40, color: Colors.blue),
              ],
            ),
          ),
          SizedBox(height: 24),
          Text(
            '3D Model Hazırlanıyor',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(_downloadProgress, style: TextStyle(color: Colors.grey[600])),
          if (_downloadPercentage > 0) ...[
            SizedBox(height: 16),
            Container(
              width: 200,
              height: 6,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(3),
              ),
              child: FractionallySizedBox(
                widthFactor: _downloadPercentage,
                alignment: Alignment.centerLeft,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
          ],
          SizedBox(height: 16),
          Text(
            modelName,
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: Colors.red),
            SizedBox(height: 24),
            Text(
              'Model Yüklenemedi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              _downloadProgress,
              style: TextStyle(color: Colors.grey[600]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _downloadAndConvertModel,
                  icon: Icon(Icons.refresh),
                  label: Text('Tekrar Dene'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
                SizedBox(width: 16),
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      _downloadError = false;
                      _dataUrlModel = null;
                    });
                  },
                  icon: Icon(Icons.link),
                  label: Text('Direkt URL'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNormalView() {
    String modelSrc = selectedModel;
    debugPrint('ModelViewer src length: ${modelSrc.length}');
    debugPrint(
      'ModelViewer src type: ${modelSrc.startsWith('data:') ? 'Data URL' : 'Regular URL'}',
    );

    return ModelViewer(
      backgroundColor: Color.fromARGB(0xFF, 0xEE, 0xEE, 0xEE),
      src: modelSrc,
      alt: "3D Model",
      ar: arEnabled,
      autoRotate: autoRotate,
      cameraControls: cameraControls,
      disableZoom: false,
      rotationPerSecond: "30deg",
      animationName: null,
      autoPlay: true,
      cameraOrbit: "45deg 55deg 4m",
      fieldOfView: "30deg",
      exposure: 1.0,
      shadowIntensity: 0.3,
      loading: Loading.eager,
      reveal: Reveal.auto,
      onWebViewCreated: (controller) {
        debugPrint("ModelViewer oluşturuldu");
      },
    );
  }

  Widget _buildARView() {
    if (!isCameraInitialized || _cameraController == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.green),
            SizedBox(height: 16),
            Text('Kamera başlatılıyor...'),
          ],
        ),
      );
    }

    return Stack(
      children: [
        Positioned.fill(child: CameraPreview(_cameraController!)),
        Positioned(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: ModelViewer(
            backgroundColor: Colors.transparent,
            src: selectedModel,
            alt: "AR 3D Model",
            ar: false,
            autoRotate: autoRotate,
            cameraControls: true,
            disableZoom: false,
            animationName: null,
            autoPlay: true,
            cameraOrbit: "45deg 55deg 4m",
            fieldOfView: "45deg",
            exposure: 1.2,
            shadowIntensity: 0.1,
            rotationPerSecond: autoRotate ? "30deg" : null,
            loading: Loading.eager,
            reveal: Reveal.auto,
            onWebViewCreated: (controller) {
              debugPrint("AR ModelViewer oluşturuldu");
            },
          ),
        ),
        _buildAROverlay(),
        if (_showInfoPanel) _buildARInfoPanel(),
      ],
    );
  }

  Widget _buildAROverlay() {
    return Positioned(
      top: 16,
      left: 16,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.camera_alt, color: Colors.white, size: 16),
            SizedBox(width: 8),
            Text(
              widget.isFirebaseUrl
                  ? (_dataUrlModel != null
                      ? 'AR - Data URL'
                      : 'AR - Firebase URL')
                  : 'AR Modda',
              style: TextStyle(color: Colors.white, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildARInfoPanel() {
    return Positioned(
      top: 0,
      left: 16,
      right: 16,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.9),
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(16),
            bottomRight: Radius.circular(16),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'AR Kontrol Rehberi',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _showInfoPanel = false;
                    });
                  },
                  child: Icon(Icons.close, color: Colors.white, size: 20),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildGestureInfo('✋', 'Elle\nTaşı'),
                _buildGestureInfo('🔄', 'Dokunma\nDöndür'),
                _buildGestureInfo('📱', 'Tuşlar\nBoyut'),
                _buildGestureInfo('🔄', 'Reset\nSıfırla'),
              ],
            ),
            if (widget.isFirebaseUrl) ...[
              SizedBox(height: 12),
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color:
                      _dataUrlModel != null
                          ? Colors.green.withOpacity(0.2)
                          : Colors.orange.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color:
                        _dataUrlModel != null
                            ? Colors.green.withOpacity(0.3)
                            : Colors.orange.withOpacity(0.3),
                  ),
                ),
                child: Text(
                  _dataUrlModel != null
                      ? '✅ Data URL formatında yüklendi'
                      : '🌐 Direkt URL kullanılıyor',
                  style: TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showModelInfoDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  showARView ? Colors.green[50]! : Colors.blue[50]!,
                  showARView ? Colors.green[100]! : Colors.blue[100]!,
                ],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(
                      widget.isFirebaseUrl ? Icons.cloud : Icons.view_in_ar,
                      color: showARView ? Colors.green : Colors.blue,
                      size: 32,
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        modelName,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Divider(),
                SizedBox(height: 16),
                _buildInfoRow('📄', 'Model Adı', modelName),
                if (widget.modelDescription != null)
                  _buildInfoRow('📝', 'Açıklama', widget.modelDescription!),
                _buildInfoRow(
                  '📁',
                  'Kaynak',
                  widget.isFirebaseUrl ? 'Firebase Storage' : 'Yerel Asset',
                ),
                _buildInfoRow(
                  '🎯',
                  'Mod',
                  showARView ? 'AR Modu' : '3D Görüntüleme',
                ),
                if (widget.isFirebaseUrl) ...[
                  _buildInfoRow(
                    '🔗',
                    'Format',
                    _dataUrlModel != null
                        ? 'Data URL (Base64)'
                        : _downloadError
                        ? 'Direkt URL'
                        : 'Hazırlanıyor...',
                  ),
                  if (_dataUrlModel != null)
                    _buildInfoRow(
                      '💾',
                      'Boyut',
                      '${(_dataUrlModel!.length / 1024 / 1024).toStringAsFixed(1)} MB',
                    ),
                ],
                SizedBox(height: 20),
                Row(
                  children: [
                    if (widget.isFirebaseUrl &&
                        (_downloadError || _dataUrlModel == null)) ...[
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pop();
                            _downloadAndConvertModel();
                          },
                          icon: Icon(Icons.cloud_download),
                          label: Text('Yeniden Hazırla'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                    ],
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed:
                            _isDownloading
                                ? null
                                : () {
                                  Navigator.of(context).pop();
                                  setState(() {
                                    showARView = !showARView;
                                    if (!showARView) _showInfoPanel = false;
                                  });
                                },
                        icon: Icon(
                          showARView ? Icons.view_in_ar : Icons.view_in_ar,
                        ),
                        label: Text(showARView ? 'Normal Mod' : 'AR Mod'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              showARView ? Colors.green : Colors.blue,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(String icon, String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(icon, style: TextStyle(fontSize: 18)),
          SizedBox(width: 12),
          Text(
            '$label: ',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          Expanded(
            child: Text(value, style: TextStyle(color: Colors.grey[800])),
          ),
        ],
      ),
    );
  }

  Widget _buildGestureInfo(String emoji, String text) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(emoji, style: TextStyle(fontSize: 20)),
          SizedBox(height: 4),
          Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 9),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }
}
