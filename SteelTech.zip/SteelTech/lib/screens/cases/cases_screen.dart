import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutScreen extends StatefulWidget {
  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  Map<String, dynamic>? companyData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _loadCompanyData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadCompanyData() async {
    try {
      // Firebase'den şirket verilerini getir
      DocumentSnapshot doc =
          await FirebaseFirestore.instance
              .collection('companyInfo')
              .doc('OKzWNqqRwORGxIYjKeeM5TTTZHH2') // User ID
              .get();

      if (doc.exists) {
        setState(() {
          companyData = doc.data() as Map<String, dynamic>;
          isLoading = false;
        });
        _animationController.forward();
      }
    } catch (e) {
      print('Veri yükleme hatası: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Hakkımızda',
          style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white),
        ),
        backgroundColor: Color(0xFF667EEA),
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body:
          isLoading
              ? _buildLoadingWidget()
              : companyData == null
              ? _buildErrorWidget()
              : FadeTransition(opacity: _fadeAnimation, child: _buildContent()),
    );
  }

  Widget _buildLoadingWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667EEA)),
          ),
          SizedBox(height: 16),
          Text(
            'Bilgiler yükleniyor...',
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 64, color: Colors.grey[400]),
          SizedBox(height: 16),
          Text(
            'Veriler yüklenemedi',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 8),
          ElevatedButton(
            onPressed: _loadCompanyData,
            child: Text('Tekrar Dene'),
            style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF667EEA)),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    final basicInfo = companyData!['basicInfo'] as Map<String, dynamic>? ?? {};
    final services = companyData!['services'] as List<dynamic>? ?? [];
    final advantages = companyData!['advantages'] as List<dynamic>? ?? [];
    final contact = companyData!['contact'] as Map<String, dynamic>? ?? {};

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCompanyHeader(basicInfo),
          SizedBox(height: 24),
          _buildAboutSection(basicInfo),
          SizedBox(height: 24),
          _buildServicesSection(services),
          SizedBox(height: 24),
          _buildAdvantagesSection(advantages),
          SizedBox(height: 24),
          _buildContactSection(contact),
          SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildCompanyHeader(Map<String, dynamic> basicInfo) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Color(0xFF667EEA).withOpacity(0.3),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          CachedNetworkImage(
            imageUrl: basicInfo['logoUrl'],
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              width: 80,
              height: 80,
              color: Colors.white.withOpacity(0.2),
              child: Center(
                child: CircularProgressIndicator(),
              ),
            ),
            errorWidget: (context, url, error) => Container(
              width: 80,
              height: 80,
              color: Colors.white.withOpacity(0.2),
              child: Icon(Icons.business, size: 40, color: Colors.white),
            ),
          ),

          SizedBox(height: 25),
          Text(
            basicInfo['name'] ?? 'Şirket Adı',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            basicInfo['slogan'] ?? 'Slogan',
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
          if (basicInfo['foundedYear'] != null) ...[
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${DateTime.now().year - basicInfo['foundedYear']} Yıllık Deneyim',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAboutSection(Map<String, dynamic> basicInfo) {
    return _buildSection(
      title: 'Firmamız Hakkında',
      icon: Icons.info_outline,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (basicInfo['shortDescription'] != null) ...[
            Text(
              basicInfo['shortDescription'],
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
                height: 1.6,
              ),
            ),
            SizedBox(height: 16),
          ],
          if (basicInfo['detailedDescription'] != null) ...[
            Text(
              basicInfo['detailedDescription'],
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
                height: 1.5,
              ),
            ),
            SizedBox(height: 20),
          ],
          Row(
            children: [
              if (basicInfo['foundedYear'] != null)
                _buildInfoChip(
                  icon: Icons.calendar_today,
                  label: 'Kuruluş',
                  value: basicInfo['foundedYear'].toString(),
                ),
              SizedBox(width: 12),
              if (basicInfo['employeeCount'] != null)
                _buildInfoChip(
                  icon: Icons.people,
                  label: 'Çalışan',
                  value: '${basicInfo['employeeCount']}+',
                ),
            ],
          ),
          if (basicInfo['mission'] != null || basicInfo['vision'] != null) ...[
            SizedBox(height: 20),
            if (basicInfo['mission'] != null) ...[
              _buildMissionVisionCard(
                title: 'Misyonumuz',
                content: basicInfo['mission'],
                color: Color(0xFF2ED573),
                icon: Icons.flag,
              ),
              SizedBox(height: 12),
            ],
            if (basicInfo['vision'] != null)
              _buildMissionVisionCard(
                title: 'Vizyonumuz',
                content: basicInfo['vision'],
                color: Color(0xFF3742FA),
                icon: Icons.visibility,
              ),
          ],
        ],
      ),
    );
  }

  Widget _buildServicesSection(List<dynamic> services) {
    if (services.isEmpty) return SizedBox.shrink();

    return _buildSection(
      title: 'Hizmetlerimiz',
      icon: Icons.design_services,
      child: Column(
        children:
            services.map<Widget>((service) {
              return _buildServiceCard(service as Map<String, dynamic>);
            }).toList(),
      ),
    );
  }

  Widget _buildAdvantagesSection(List<dynamic> advantages) {
    if (advantages.isEmpty) return SizedBox.shrink();

    return _buildSection(
      title: 'Neden Bizi Seçmelisiniz?',
      icon: Icons.star_outline,
      child: Column(
        children:
            advantages.map<Widget>((advantage) {
              return _buildAdvantageCard(advantage as Map<String, dynamic>);
            }).toList(),
      ),
    );
  }

  Widget _buildContactSection(Map<String, dynamic> contact) {
    return _buildSection(
      title: 'İletişim Bilgileri',
      icon: Icons.contact_phone,
      child: Column(
        children: [
          if (contact['address'] != null)
            _buildContactItem(
              icon: Icons.location_on,
              title: 'Adres',
              content: contact['address'],
              onTap: () => _launchMaps(contact['address']),
            ),
          if (contact['phone'] != null)
            _buildContactItem(
              icon: Icons.phone,
              title: 'Telefon',
              content: contact['phone'],
              onTap: () => _launchPhone(contact['phone']),
            ),
          if (contact['whatsapp'] != null)
            _buildContactItem(
              icon: Icons.chat,
              title: 'WhatsApp',
              content: contact['whatsapp'],
              onTap: () => _launchWhatsApp(contact['whatsapp']),
            ),
          if (contact['email'] != null)
            _buildContactItem(
              icon: Icons.email,
              title: 'E-posta',
              content: contact['email'],
              onTap:
                  () =>
                      _launchEmail(contact['email'], "subjectsss", "bodiesss"),
            ),
          if (contact['website'] != null)
            _buildContactItem(
              icon: Icons.language,
              title: 'Web Sitesi',
              content: contact['website'],
              onTap: () => _launchUrl(contact['website']),
            ),
          if (contact['workingHours'] != null)
            _buildContactItem(
              icon: Icons.access_time,
              title: 'Çalışma Saatleri',
              content: contact['workingHours'],
            ),
        ],
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF667EEA).withOpacity(0.1),
                  Colors.transparent,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Color(0xFF667EEA),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: Colors.white, size: 20),
                ),
                SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2E3A47),
                  ),
                ),
              ],
            ),
          ),
          Padding(padding: EdgeInsets.all(20), child: child),
        ],
      ),
    );
  }

  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Color(0xFF667EEA).withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Color(0xFF667EEA)),
          SizedBox(width: 6),
          Text(
            '$label: $value',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Color(0xFF667EEA),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMissionVisionCard({
    required String title,
    required String content,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            content,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[700],
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceCard(Map<String, dynamic> service) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Color(0xFF667EEA).withOpacity(0.1),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Icon(
              _getIconFromString(service['icon'] ?? 'business'),
              color: Color(0xFF667EEA),
              size: 24,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  service['name'] ?? 'Hizmet',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2E3A47),
                  ),
                ),
                if (service['description'] != null) ...[
                  SizedBox(height: 4),
                  Text(
                    service['description'],
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdvantageCard(Map<String, dynamic> advantage) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green[200]!),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Icon(
              _getIconFromString(advantage['icon'] ?? 'star'),
              color: Colors.green[700],
              size: 24,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  advantage['title'] ?? 'Avantaj',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2E3A47),
                  ),
                ),
                if (advantage['description'] != null) ...[
                  SizedBox(height: 4),
                  Text(
                    advantage['description'],
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactItem({
    required IconData icon,
    required String title,
    required String content,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[50],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[200]!),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Color(0xFF667EEA).withOpacity(0.1),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(icon, color: Color(0xFF667EEA), size: 24),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF667EEA),
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    content,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF2E3A47),
                    ),
                  ),
                ],
              ),
            ),
            if (onTap != null)
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey[400]),
          ],
        ),
      ),
    );
  }

  IconData _getIconFromString(String iconName) {
    switch (iconName.toLowerCase()) {
      case 'web':
        return Icons.language;
      case 'mobile':
        return Icons.phone_android;
      case 'design':
        return Icons.design_services;
      case 'laptop':
        return Icons.laptop;
      case 'phone':
        return Icons.phone;
      case 'marketing':
        return Icons.campaign;
      case 'support':
        return Icons.support_agent;
      case 'team':
        return Icons.group;
      case 'quality':
        return Icons.verified;
      case 'experience':
        return Icons.access_time;
      case 'innovation':
        return Icons.lightbulb;
      case 'trust':
        return Icons.security;
      case 'speed':
        return Icons.speed;
      case 'consulting':
        return Icons.psychology;
      case 'analytics':
        return Icons.analytics;
      case 'security':
        return Icons.security;
      case 'cloud':
        return Icons.cloud;
      case 'database':
        return Icons.storage;
      case 'ai':
        return Icons.smart_toy;
      default:
        return Icons.business;
    }
  }

  Future<void> _launchUrl(String url) async {
    if (!await launchUrl(Uri.parse(url))) {
      throw Exception('Could not launch $url');
    }
  }

  Future<void> _launchPhone(String phone) async {
    final Uri launchUri = Uri(scheme: 'tel', path: phone);
    await launchUrl(launchUri);
  }

  Future<void> _launchEmail(String email, String subject, String body) async {
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: email,
      query:
          'subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(body)}',
    );

    if (await canLaunchUrl(emailUri)) {
      await launchUrl(emailUri);
    }
  }

  Future<void> _launchWhatsApp(String phone) async {
    final url =
        'https://wa.me/${phone.replaceAll(RegExp(r'[^\d]'), '')}?text=${Uri.encodeComponent("Merhaba, Bilgi Almak İstiyorum.")}';

    if (!await launchUrl(Uri.parse(url))) {
      throw Exception('Could not launch $url');
    }
  }

  Future<void> _launchMaps(String address) async {
    final url =
        'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}';
    if (!await launchUrl(Uri.parse(url))) {
      throw Exception('Could not launch $url');
    }
  }
}
