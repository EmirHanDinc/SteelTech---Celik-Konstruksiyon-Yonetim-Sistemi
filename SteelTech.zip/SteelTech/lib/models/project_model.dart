class Project {
  final int id;
  final String title;
  final String category;
  final String imageUrl;
  final String area;
  final String year;
  final String status;
  final String location;
  final String duration;
  final String budget;
  final String description;
  final List<String> materials;
  final Map<String, String> technicalSpecs;
  final List<String> certificates;

  Project({
    required this.id,
    required this.title,
    required this.category,
    required this.imageUrl,
    required this.area,
    required this.year,
    required this.status,
    required this.location,
    required this.duration,
    required this.budget,
    required this.description,
    required this.materials,
    required this.technicalSpecs,
    required this.certificates,
  });
}